/**
 * 
 */

/**
 * @author David Price
 *
 */
public class BurrowsWheeler {
	// apply Burrows-Wheeler transform, reading from standard input and writing to standard output
    public static void transform() {
    	
    }

    // apply Burrows-Wheeler inverse transform, reading from standard input and writing to standard output
    public static void inverseTransform() {
    	
    }

    // if args[0] is '-', apply Burrows-Wheeler transform
    // if args[0] is '+', apply Burrows-Wheeler inverse transform
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
