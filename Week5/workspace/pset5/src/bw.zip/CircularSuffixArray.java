
/**
 * @author David Price
 *
 */
public class CircularSuffixArray {
	
	private String string;
	
	
	// circular suffix array of s
	public CircularSuffixArray(String s) {
		
	}
	
	// length of s
	public int length() {
		return string.length();
	}
	
	// returns index of ith sorted suffix
	public int index(int i) {
		return 0;
	}
	
	
	/**
	 * unit testing (required)
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
